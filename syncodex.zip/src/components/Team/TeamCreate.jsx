import { useState } from 'react';
import { getFirestore, collection, addDoc, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { auth } from '../../firebase';
import { useNavigate } from 'react-router-dom';
import { jellyTriangle } from 'ldrs';

jellyTriangle.register();

export default function TeamCreate() {
  const navigate = useNavigate();
  const [teamName, setTeamName] = useState('');
  const [description, setDescription] = useState('');
  const [teamImage, setTeamImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [imagePreview, setImagePreview] = useState(null);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setError('Image size must be less than 5MB');
        return;
      }
      setTeamImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!auth.currentUser) {
      navigate('/');
      return;
    }

    // Validate team name length according to rules
    if (teamName.trim().length < 3 || teamName.trim().length > 50) {
      setError('Team name must be between 3 and 50 characters');
      return;
    }

    if (description && description.length > 1000) {
      setError('Team description must not exceed 1000 characters');
      return;
    }

    if (!teamName.trim()) {
      setError('Please enter a team name');
      return;
    }

    try {
      setLoading(true);
      setError('');

      const db = getFirestore();
      const storage = getStorage();
      let teamImageUrl = null;

      // Upload team image if provided
      if (teamImage) {
        try {
          const imageRef = ref(storage, `teams/${Date.now()}_${teamImage.name}`);
          await uploadBytes(imageRef, teamImage);
          teamImageUrl = await getDownloadURL(imageRef);
        } catch (imageError) {
          console.error('Error uploading image:', imageError);
          setError('Failed to upload team image. Please try again.');
          setLoading(false);
          return;
        }
      }

      // Create team document
      const teamData = {
        name: teamName.trim(),
        description: description?.trim() || '',
        imageUrl: teamImageUrl,
        createdBy: auth.currentUser.uid,
        createdAt: serverTimestamp(),
        members: [],
        activeMembers: [{
          userId: auth.currentUser.uid,
          displayName: auth.currentUser.displayName || 'Anonymous',
          photoURL: auth.currentUser.photoURL,
          role: 'admin',
          joinedAt: serverTimestamp()
        }],
        admins: [auth.currentUser.uid],
        lastActivity: serverTimestamp(),
        settings: {
          isPublic: true,
          allowInvites: true,
          memberPermissions: {
            canInvite: true,
            canRemove: false,
            canEditTeam: false
          }
        }
      };

      // Create team document with auto-generated ID
      const teamsRef = collection(db, 'teams');
      const teamRef = await addDoc(teamsRef, teamData);

      // Create initial admin document in the team's admins subcollection
      const adminDocRef = doc(db, 'teams', teamRef.id, 'admins', auth.currentUser.uid);
      await setDoc(adminDocRef, {
        userId: auth.currentUser.uid,
        displayName: auth.currentUser.displayName || 'Anonymous',
        photoURL: auth.currentUser.photoURL,
        role: 'admin',
        addedAt: serverTimestamp()
      });

      navigate(`/team/${teamRef.id}`);
    } catch (error) {
      console.error('Error creating team:', error);
      setError('Failed to create team. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f0f0f] pt-16 pb-16 px-4">
      <div className="max-w-2xl mx-auto bg-gray-800 rounded-lg p-6">
        <h1 className="text-2xl font-bold text-white mb-6">Create New Team</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Team Image Upload */}
          <div>
            <label className="block text-white mb-2">Team Image</label>
            <div className="flex items-center space-x-4">
              <div className="w-24 h-24 bg-gray-700 rounded-lg overflow-hidden flex items-center justify-center">
                {imagePreview ? (
                  <img src={imagePreview} alt="Team" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-gray-400">No image</span>
                )}
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="text-sm text-gray-400"
              />
            </div>
          </div>

          {/* Team Name */}
          <div>
            <label className="block text-white mb-2">Team Name *</label>
            <input
              type="text"
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter team name"
              required
            />
          </div>

          {/* Team Description */}
          <div>
            <label className="block text-white mb-2">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter team description"
              rows="4"
            />
          </div>

          {error && (
            <div className="text-red-500">{error}</div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {loading ? (
              <l-jelly-triangle
                size="40"
                speed="1.75"
                color="white"
              ></l-jelly-triangle>
            ) : (
              'Create Team'
            )}
          </button>
        </form>
      </div>
    </div>
  );
}