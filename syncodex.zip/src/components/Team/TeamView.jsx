import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getFirestore, doc, getDoc, updateDoc, collection, addDoc } from 'firebase/firestore';
import { auth } from '../../firebase';
import TeamChat from './TeamChat';

export default function TeamView() {
  const { teamId } = useParams();
  const navigate = useNavigate();
  const [team, setTeam] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [userRole, setUserRole] = useState(null);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('member');
  const db = getFirestore();

  useEffect(() => {
    const fetchTeam = async () => {
      if (!teamId) return;

      try {
        const teamRef = doc(db, 'teams', teamId);
        const teamSnap = await getDoc(teamRef);

        if (teamSnap.exists()) {
          const teamData = {
            id: teamSnap.id,
            ...teamSnap.data()
          };
          setTeam(teamData);

          // Check user role
          if (teamData.createdBy === auth.currentUser?.uid) {
            setUserRole('admin');
          } else {
            const activeMember = teamData.activeMembers?.find(
              member => member.userId === auth.currentUser?.uid
            );
            setUserRole(activeMember ? 'member' : null);
          }
        } else {
          setError('Team not found');
        }
      } catch (error) {
        console.error('Error fetching team:', error);
        setError('Failed to load team');
      } finally {
        setLoading(false);
      }
    };

    fetchTeam();
  }, [teamId, db]);

  const handleInviteMember = async (e) => {
    e.preventDefault();
    if (!inviteEmail.trim()) return;

    try {
      const teamRef = doc(db, 'teams', teamId);
      await updateDoc(teamRef, {
        members: [
          ...team.members,
          {
            email: inviteEmail.trim(),
            role: inviteRole,
            status: 'pending',
            invitedBy: auth.currentUser.uid,
            invitedAt: new Date().toISOString()
          }
        ]
      });

      setInviteEmail('');
      setShowInviteModal(false);
    } catch (error) {
      console.error('Error inviting member:', error);
      setError('Failed to invite member');
    }
  };

  const handleLeaveTeam = async () => {
    if (!auth.currentUser || !team || userRole === 'admin') return;

    try {
      const teamRef = doc(db, 'teams', teamId);
      
      await updateDoc(teamRef, {
        activeMembers: team.activeMembers.filter(m => m.userId !== auth.currentUser.uid),
        members: [
          ...team.members.filter(m => m.email !== auth.currentUser.email),
          {
            email: auth.currentUser.email,
            role: 'member',
            status: 'left',
            leftAt: new Date().toISOString(),
            joinedAt: team.activeMembers.find(m => m.userId === auth.currentUser.uid)?.joinedAt
          }
        ]
      });

      navigate('/teams');
    } catch (error) {
      console.error('Error leaving team:', error);
      setError('Failed to leave team');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0f0f0f] pt-16 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  if (!team) {
    return (
      <div className="min-h-screen bg-[#0f0f0f] pt-16 flex items-center justify-center">
        <div className="text-white">{error || 'Team not found'}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f0f0f] pt-16 flex">
      {/* Team Sidebar */}
      <div className="w-80 bg-gray-900 border-r border-gray-800 flex flex-col">
        {/* Team Header */}
        <div className="p-4 border-b border-gray-800">
          <div className="flex items-center space-x-3">
            {team.imageUrl ? (
              <img
                src={team.imageUrl}
                alt={team.name}
                className="w-12 h-12 rounded-full object-cover"
              />
            ) : (
              <div className="w-12 h-12 bg-gray-700 rounded-full flex items-center justify-center text-white font-medium">
                {team.name[0].toUpperCase()}
              </div>
            )}
            <div>
              <h1 className="text-lg font-semibold text-white">{team.name}</h1>
              <p className="text-sm text-gray-400">{team.activeMembers?.length || 0} members</p>
            </div>
          </div>
        </div>

        {/* Team Members */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-medium text-gray-400">MEMBERS</h2>
              {userRole === 'admin' && (
                <button
                  onClick={() => setShowInviteModal(true)}
                  className="text-sm text-blue-500 hover:text-blue-400 transition-colors"
                >
                  Add
                </button>
              )}
            </div>

            <div className="space-y-2">
              {team.activeMembers?.map((member) => (
                <div key={member.userId} className="flex items-center space-x-3">
                  {member.photoURL ? (
                    <img
                      src={member.photoURL}
                      alt={member.displayName}
                      className="w-8 h-8 rounded-full"
                    />
                  ) : (
                    <div className="w-8 h-8 bg-gray-700 rounded-full flex items-center justify-center text-white">
                      {member.displayName[0].toUpperCase()}
                    </div>
                  )}
                  <div>
                    <p className="text-sm font-medium text-white">{member.displayName}</p>
                    <p className="text-xs text-gray-400">{member.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Team Actions */}
        {userRole === 'member' && (
          <div className="p-4 border-t border-gray-800">
            <button
              onClick={handleLeaveTeam}
              className="w-full px-4 py-2 text-red-500 hover:bg-red-500/10 rounded transition-colors"
            >
              Leave Team
            </button>
          </div>
        )}
      </div>

      {/* Chat Area */}
      <div className="flex-1">
        <TeamChat />
      </div>

      {/* Invite Member Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h3 className="text-xl font-semibold text-white mb-4">Invite Member</h3>
            <form onSubmit={handleInviteMember}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-700 text-white rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Role
                  </label>
                  <select
                    value={inviteRole}
                    onChange={(e) => setInviteRole(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-700 text-white rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="member">Member</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowInviteModal(false)}
                  className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
                >
                  Send Invitation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}