import { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { getFirestore, doc, getDoc, updateDoc, arrayUnion } from 'firebase/firestore';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { auth } from '../../firebase';
import { jellyTriangle } from 'ldrs';

jellyTriangle.register();

export default function TeamJoin() {
  const { teamId } = useParams();
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [team, setTeam] = useState(null);

  useEffect(() => {
    const processInvitation = async () => {
      if (!teamId || !token || !auth.currentUser) {
        setError('Invalid invitation link or you need to be logged in');
        setLoading(false);
        return;
      }

      try {
        // Get team data to display
        const db = getFirestore();
        const teamRef = doc(db, 'teams', teamId);
        const teamSnap = await getDoc(teamRef);
        
        if (!teamSnap.exists()) {
          setError('Team not found');
          setLoading(false);
          return;
        }
        
        setTeam({
          id: teamSnap.id,
          ...teamSnap.data()
        });

        // Process the invitation using Cloud Function
        const functions = getFunctions();
        const processTeamInvitation = httpsCallable(functions, 'processTeamInvitation');
        
        const result = await processTeamInvitation({
          token,
          teamId
        });
        
        if (result.data.success) {
          setSuccess(true);
        } else {
          setError('Failed to process invitation');
        }
      } catch (error) {
        console.error('Error processing invitation:', error);
        setError(error.message || 'Failed to process invitation');
      } finally {
        setLoading(false);
      }
    };

    processInvitation();
  }, [teamId, token, navigate]);

  const handleGoToTeam = () => {
    navigate(`/team/${teamId}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0f0f0f] pt-16 flex items-center justify-center">
        <l-jelly-triangle
          size="40"
          speed="1.75"
          color="white"
        ></l-jelly-triangle>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f0f0f] pt-16 pb-16 px-4">
      <div className="max-w-md mx-auto bg-gray-800 rounded-lg p-6 mt-8">
        {error ? (
          <div className="text-center">
            <div className="text-red-500 text-xl mb-4">{error}</div>
            <p className="text-gray-400 mb-6">There was a problem processing your invitation.</p>
            <button
              onClick={() => navigate('/teams')}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              Go to Teams
            </button>
          </div>
        ) : success ? (
          <div className="text-center">
            <div className="text-green-500 text-xl mb-4">Invitation Accepted!</div>
            <p className="text-white mb-2">You have successfully joined the team:</p>
            <p className="text-xl font-bold text-white mb-6">{team?.name}</p>
            <button
              onClick={handleGoToTeam}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              Go to Team
            </button>
          </div>
        ) : (
          <div className="text-center">
            <div className="text-xl text-white mb-4">Processing Invitation...</div>
            <l-jelly-triangle
              size="30"
              speed="1.75"
              color="white"
            ></l-jelly-triangle>
          </div>
        )}
      </div>
    </div>
  );
}