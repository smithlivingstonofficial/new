import { useState, useEffect, useRef } from 'react';
import { getFirestore, collection, query, orderBy, limit, addDoc, serverTimestamp, onSnapshot, where } from 'firebase/firestore';
import { auth } from '../../firebase';
import { useParams } from 'react-router-dom';
import { BsSend, BsEmojiSmile, BsPaperclip } from 'react-icons/bs';

export default function TeamChat() {
  const { teamId } = useParams();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [error, setError] = useState('');
  const messagesEndRef = useRef(null);
  const db = getFirestore();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (!teamId || !auth.currentUser) return;

    const messagesRef = collection(db, 'teams', teamId, 'messages');
    const q = query(
      messagesRef,
      orderBy('timestamp', 'asc'),
      limit(100)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const newMessages = [];
      snapshot.forEach((doc) => {
        newMessages.push({ id: doc.id, ...doc.data() });
      });
      setMessages(newMessages);
      scrollToBottom();
    }, (err) => {
      console.error('Error fetching messages:', err);
      setError('Failed to load messages');
    });

    return () => unsubscribe();
  }, [teamId, db]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !teamId || !auth.currentUser) return;

    try {
      const messagesRef = collection(db, 'teams', teamId, 'messages');
      await addDoc(messagesRef, {
        text: newMessage.trim(),
        userId: auth.currentUser.uid,
        userDisplayName: auth.currentUser.displayName || 'Anonymous',
        userPhotoURL: auth.currentUser.photoURL,
        timestamp: serverTimestamp()
      });

      setNewMessage('');
    } catch (err) {
      console.error('Error sending message:', err);
      setError('Failed to send message');
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-16rem)] bg-gray-900 rounded-lg overflow-hidden">
      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {error && (
          <div className="text-red-500 text-center p-2">{error}</div>
        )}
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex items-start space-x-2 ${message.userId === auth.currentUser?.uid ? 'justify-end' : 'justify-start'}`}
          >
            {message.userId !== auth.currentUser?.uid && (
              <div className="flex-shrink-0">
                {message.userPhotoURL ? (
                  <img
                    src={message.userPhotoURL}
                    alt={message.userDisplayName}
                    className="w-8 h-8 rounded-full"
                  />
                ) : (
                  <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center text-white">
                    {message.userDisplayName[0].toUpperCase()}
                  </div>
                )}
              </div>
            )}
            <div
              className={`max-w-[70%] break-words rounded-lg p-3 ${message.userId === auth.currentUser?.uid
                ? 'bg-blue-600 text-white'
                : 'bg-gray-700 text-white'
                }`}
            >
              {message.userId !== auth.currentUser?.uid && (
                <div className="text-sm text-gray-300 mb-1">
                  {message.userDisplayName}
                </div>
              )}
              <div>{message.text}</div>
              <div className="text-xs text-gray-300 mt-1">
                {message.timestamp?.toDate().toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <form onSubmit={handleSendMessage} className="p-4 bg-gray-800 border-t border-gray-700">
        <div className="flex items-center space-x-2">
          <button
            type="button"
            className="p-2 text-gray-400 hover:text-white transition-colors"
            onClick={() => { /* Implement emoji picker */ }}
          >
            <BsEmojiSmile className="w-5 h-5" />
          </button>
          <button
            type="button"
            className="p-2 text-gray-400 hover:text-white transition-colors"
            onClick={() => { /* Implement file attachment */ }}
          >
            <BsPaperclip className="w-5 h-5" />
          </button>
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message"
            className="flex-1 bg-gray-700 text-white rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="submit"
            disabled={!newMessage.trim()}
            className="p-2 text-blue-500 hover:text-blue-400 transition-colors disabled:text-gray-500"
          >
            <BsSend className="w-5 h-5" />
          </button>
        </div>
      </form>
    </div>
  );
}