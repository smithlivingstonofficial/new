import { useState, useEffect } from 'react';
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject, uploadBytesResumable } from 'firebase/storage';
import { getFirestore, collection, addDoc } from 'firebase/firestore';
import { auth } from '../firebase';
import { useNavigate } from 'react-router-dom';
import { useSidebar } from '../contexts/SidebarContext';

export default function Upload() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [uploadProgress, setUploadProgress] = useState({
    sourceCode: 0,
    thumbnail: 0
  });
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    programmingLanguages: '',
    sourceCode: null,
    thumbnail: null,
    visibility: 'public',
    password: ''
  });
  const [thumbnailPreview, setThumbnailPreview] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateFile = (file, type) => {
    const maxSizes = {
      sourceCode: 50 * 1024 * 1024, // 50MB
      thumbnail: 5 * 1024 * 1024 // 5MB
    };

    const allowedTypes = {
      sourceCode: [
        'application/zip',
        'application/x-zip-compressed',
        'application/x-rar-compressed',
        'application/x-7z-compressed',
        'text/plain',
        'text/javascript',
        'application/javascript',
        'text/x-python',
        'application/x-python',
        'text/x-java',
        'text/x-c',
        'text/x-c++',
        'text/html',
        'text/css'
      ],
      thumbnail: ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
    };

    if (file.size > maxSizes[type]) {
      throw new Error(`${type === 'sourceCode' ? 'Source code' : 'Thumbnail'} file size must be less than ${maxSizes[type] / (1024 * 1024)}MB`);
    }

    if (!allowedTypes[type].includes(file.type)) {
      throw new Error(`Invalid ${type === 'sourceCode' ? 'source code' : 'thumbnail'} file type`);
    }

    return true;
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    const file = files[0];

    try {
      if (name === 'thumbnail') {
        validateFile(file, 'thumbnail');
        setFormData(prev => ({
          ...prev,
          thumbnail: file
        }));
        const previewUrl = URL.createObjectURL(file);
        setThumbnailPreview(previewUrl);
      } else if (name === 'sourceCode') {
        validateFile(file, 'sourceCode');
        setFormData(prev => ({
          ...prev,
          sourceCode: file
        }));
      }
      setError(null);
    } catch (err) {
      setError(err.message);
      e.target.value = '';
    }
  };

  useEffect(() => {
    return () => {
      if (thumbnailPreview) {
        URL.revokeObjectURL(thumbnailPreview);
      }
    };
  }, [thumbnailPreview]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!auth.currentUser) {
      setError('Please login to upload projects');
      return;
    }

    setError(null);

    // Validate required fields
    if (!formData.title.trim()) {
      setError('Project title is required');
      return;
    }

    if (!formData.description.trim()) {
      setError('Project description is required');
      return;
    }

    if (!formData.programmingLanguages.trim()) {
      setError('Programming languages are required');
      return;
    }

    if (!formData.sourceCode) {
      setError('Source code file is required');
      return;
    }

    if (formData.visibility === 'private' && !formData.password) {
      setError('Password is required for private projects');
      return;
    }

    try {
      setLoading(true);
      let sourceCodeData = null;
      let thumbnailData = null;

      // Upload source code file
      try {
        const storage = getStorage();
        const timestamp = Date.now();
        const fileExtension = formData.sourceCode.name.split('.').pop();
        const sanitizedFileName = `${formData.title.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${timestamp}.${fileExtension}`;
        const sourceCodeRef = ref(storage, `projects/${auth.currentUser.uid}/${sanitizedFileName}`);
        
        const sourceCodeUploadTask = uploadBytesResumable(sourceCodeRef, formData.sourceCode);

        // Add progress monitoring
        sourceCodeUploadTask.on('state_changed',
          (snapshot) => {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            setUploadProgress(prev => ({
              ...prev,
              sourceCode: progress
            }));
          },
          (error) => {
            console.error('Error during source code upload:', error);
            throw new Error(`Failed to upload source code: ${error.message || 'Please check your file and try again'}`);
          }
        );

        await sourceCodeUploadTask;
        const sourceCodeUrl = await getDownloadURL(sourceCodeRef);
        sourceCodeData = {
          ref: sourceCodeRef,
          url: sourceCodeUrl,
          fileName: sanitizedFileName
        };
      } catch (error) {
        console.error('Error uploading source code:', error);
        throw new Error(error.message || 'Failed to upload source code file. Please check your file and try again.');
      }

      // Upload thumbnail if provided
      if (formData.thumbnail) {
        try {
          const storage = getStorage();
          const timestamp = Date.now();
          const fileExtension = formData.thumbnail.name.split('.').pop();
          const sanitizedFileName = `${formData.title.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${timestamp}.${fileExtension}`;
          const thumbnailRef = ref(storage, `thumbnails/${auth.currentUser.uid}/${sanitizedFileName}`);
          
          const thumbnailUploadTask = uploadBytesResumable(thumbnailRef, formData.thumbnail);

          // Add progress monitoring
          thumbnailUploadTask.on('state_changed',
            (snapshot) => {
              const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
              setUploadProgress(prev => ({
                ...prev,
                thumbnail: progress
              }));
            },
            (error) => {
              console.error('Error during thumbnail upload:', error);
              throw new Error(`Failed to upload thumbnail: ${error.message || 'Please check your image and try again'}`);
            }
          );

          await thumbnailUploadTask;
          const thumbnailUrl = await getDownloadURL(thumbnailRef);
          thumbnailData = {
            ref: thumbnailRef,
            url: thumbnailUrl,
            fileName: sanitizedFileName
          };
        } catch (error) {
          console.error('Error uploading thumbnail:', error);
          if (sourceCodeData?.ref) {
            await deleteObject(sourceCodeData.ref);
          }
          throw new Error(error.message || 'Failed to upload thumbnail. Please check your image and try again.');
        }
      }

      // Save project metadata to Firestore
      try {
        const db = getFirestore();
        const projectData = {
          userId: auth.currentUser.uid,
          title: formData.title.trim(),
          description: formData.description.trim(),
          programmingLanguages: formData.programmingLanguages.split(',').map(lang => lang.trim()).filter(Boolean),
          sourceCodeUrl: sourceCodeData.url,
          thumbnailUrl: thumbnailData?.url || null,
          visibility: formData.visibility,
          password: formData.visibility === 'private' ? formData.password : null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          likes: [],
          downloads: 0
        };

        await addDoc(collection(db, 'projects'), projectData);
        navigate('/profile');
      } catch (error) {
        console.error('Error saving project data:', error);
        if (sourceCodeData?.ref) {
          await deleteObject(sourceCodeData.ref);
        }
        if (thumbnailData?.ref) {
          await deleteObject(thumbnailData.ref);
        }
        throw new Error('Failed to save project information. Please try again.');
      }
    } catch (error) {
      console.error('Error uploading project:', error);
      setError(error.message || 'Failed to upload project. Please try again.');
    } finally {
      setLoading(false);
      setUploadProgress({ sourceCode: 0, thumbnail: 0 });
    }
  };

  const { isCollapsed } = useSidebar();

  return (
    <div className={`min-h-screen bg-[#0f0f0f] pt-16 pb-16 md:pb-0 ${isCollapsed ? 'md:pl-20' : 'md:pl-64'} transition-all duration-300`}>
      <div className="max-w-4xl mx-auto p-8">
        <div className="bg-gray-800 rounded-lg p-6">
          <h1 className="text-2xl font-bold text-white mb-6">Upload Project</h1>
          
          {error && (
            <div className="bg-red-500 bg-opacity-20 border border-red-500 text-red-500 px-4 py-3 rounded mb-6">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="flex gap-6">
              <div className="flex-1">
                <label className="block text-white mb-2">Project Title</label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-2 bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="w-48">
                <label className="block text-white mb-2">Thumbnail</label>
                <input
                  type="file"
                  name="thumbnail"
                  onChange={handleFileChange}
                  accept="image/*"
                  className="hidden"
                  id="thumbnail-upload"
                />
                <label
                  htmlFor="thumbnail-upload"
                  className="block w-full h-32 border-2 border-dashed border-gray-600 rounded-lg cursor-pointer hover:border-blue-500 transition-colors relative"
                >
                  {thumbnailPreview ? (
                    <>
                      <img
                        src={thumbnailPreview}
                        alt="Thumbnail preview"
                        className="w-full h-full object-cover rounded-lg"
                      />
                      {uploadProgress.thumbnail > 0 && uploadProgress.thumbnail < 100 && (
                        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-lg">
                          <div className="text-white">{Math.round(uploadProgress.thumbnail)}%</div>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="flex items-center justify-center h-full text-gray-400">
                      <span>Upload Thumbnail</span>
                    </div>
                  )}
                </label>
              </div>
            </div>

            <div>
              <label className="block text-white mb-2">Project Visibility</label>
              <div className="flex space-x-4">
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    name="visibility"
                    value="public"
                    checked={formData.visibility === 'public'}
                    onChange={handleInputChange}
                    className="form-radio text-blue-500"
                  />
                  <span className="ml-2 text-white">Public</span>
                </label>
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    name="visibility"
                    value="private"
                    checked={formData.visibility === 'private'}
                    onChange={handleInputChange}
                    className="form-radio text-blue-500"
                  />
                  <span className="ml-2 text-white">Private</span>
                </label>
              </div>
            </div>

            {formData.visibility === 'private' && (
              <div>
                <label className="block text-white mb-2">Project Password</label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  required
                  placeholder="Set a password for private access"
                  className="w-full px-4 py-2 bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            )}

            <div>
              <label className="block text-white mb-2">Description</label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                required
                rows="4"
                className="w-full px-4 py-2 bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-white mb-2">Programming Languages (comma-separated)</label>
              <input
                type="text"
                name="programmingLanguages"
                value={formData.programmingLanguages}
                onChange={handleInputChange}
                required
                placeholder="e.g. JavaScript, Python, Java"
                className="w-full px-4 py-2 bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-white mb-2">Source Code</label>
              <div className="relative">
                <input
                  type="file"
                  name="sourceCode"
                  onChange={handleFileChange}
                  accept=".zip,.rar,.7z,.txt,.js,.jsx,.py,.java,.cpp,.c,.html,.css"
                  required
                  className="w-full px-4 py-2 bg-gray-700 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                />
                {uploadProgress.sourceCode > 0 && uploadProgress.sourceCode < 100 && (
                  <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-lg">
                    <div className="text-white">{Math.round(uploadProgress.sourceCode)}%</div>
                  </div>
                )}
              </div>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Uploading...' : 'Upload Project'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}