const functions = require('firebase-functions');
const admin = require('firebase-admin');
const nodemailer = require('nodemailer');

admin.initializeApp();

// Configure nodemailer with environment variables
// Note: You'll need to set these in Firebase Functions environment
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: functions.config().email.user,
    pass: functions.config().email.password
  }
});

/**
 * Cloud Function to send team invitation emails
 * Triggered when a new team is created or a member is added to a team
 */
exports.sendTeamInvitationEmail = functions.firestore
  .document('teams/{teamId}')
  .onCreate(async (snapshot, context) => {
    const teamData = snapshot.data();
    const teamId = context.params.teamId;
    
    // Get team creator info
    const creatorId = teamData.createdBy;
    const creatorSnapshot = await admin.firestore().collection('profiles').doc(creatorId).get();
    const creatorData = creatorSnapshot.data() || {};
    const creatorName = creatorData.displayName || 'Team Admin';
    
    // Send invitation emails to all pending members
    const pendingMembers = teamData.members.filter(member => member.status === 'pending');
    
    const emailPromises = pendingMembers.map(async (member) => {
      // Skip if no email is provided
      if (!member.email) return null;
      
      // Generate a unique invitation token
      const invitationToken = Math.random().toString(36).substring(2, 15) + 
                             Math.random().toString(36).substring(2, 15);
      
      // Store the invitation token in a separate collection
      await admin.firestore().collection('teamInvitations').add({
        teamId,
        email: member.email,
        token: invitationToken,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days from now
      });
      
      // Create invitation URL
      const invitationUrl = `${functions.config().app.url}/team/join/${teamId}?token=${invitationToken}`;
      
      // Email content
      const mailOptions = {
        from: `SynCodex <${functions.config().email.user}>`,
        to: member.email,
        subject: `Invitation to join ${teamData.name} team on SynCodex`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background-color: #0f0f0f; padding: 20px; text-align: center;">
              <h1 style="color: white;">SynCodex Team Invitation</h1>
            </div>
            <div style="padding: 20px; background-color: #f9f9f9;">
              <p>Hello,</p>
              <p>${creatorName} has invited you to join the <strong>${teamData.name}</strong> team on SynCodex.</p>
              
              ${teamData.description ? `<p><strong>Team Description:</strong> ${teamData.description}</p>` : ''}
              
              <p>To accept this invitation and join the team, please click the button below:</p>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${invitationUrl}" style="background-color: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">Accept Invitation</a>
              </div>
              
              <p>If you didn't expect this invitation, you can safely ignore this email.</p>
              
              <p>Best regards,<br>The SynCodex Team</p>
            </div>
            <div style="background-color: #f1f1f1; padding: 15px; text-align: center; font-size: 12px; color: #666;">
              <p>This is an automated email. Please do not reply to this message.</p>
            </div>
          </div>
        `
      };
      
      // Send email
      return transporter.sendMail(mailOptions);
    });
    
    return Promise.all(emailPromises.filter(Boolean));
  });

/**
 * Cloud Function to send team invitation emails when new members are added
 * Triggered when members array is updated in an existing team
 */
exports.sendTeamMemberInvitationEmail = functions.firestore
  .document('teams/{teamId}')
  .onUpdate(async (change, context) => {
    const beforeData = change.before.data();
    const afterData = change.after.data();
    const teamId = context.params.teamId;
    
    // Check if members array has changed
    if (JSON.stringify(beforeData.members) === JSON.stringify(afterData.members)) {
      return null; // No changes to members, exit early
    }
    
    // Find newly added members with pending status
    const beforeEmails = new Set(beforeData.members.map(m => m.email));
    const newPendingMembers = afterData.members.filter(member => 
      member.status === 'pending' && !beforeEmails.has(member.email)
    );
    
    if (newPendingMembers.length === 0) {
      return null; // No new pending members, exit early
    }
    
    // Get team admin info
    const adminId = afterData.createdBy;
    const adminSnapshot = await admin.firestore().collection('profiles').doc(adminId).get();
    const adminData = adminSnapshot.data() || {};
    const adminName = adminData.displayName || 'Team Admin';
    
    // Send invitation emails to new pending members
    const emailPromises = newPendingMembers.map(async (member) => {
      // Skip if no email is provided
      if (!member.email) return null;
      
      // Generate a unique invitation token
      const invitationToken = Math.random().toString(36).substring(2, 15) + 
                             Math.random().toString(36).substring(2, 15);
      
      // Store the invitation token in a separate collection
      await admin.firestore().collection('teamInvitations').add({
        teamId,
        email: member.email,
        token: invitationToken,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days from now
      });
      
      // Create invitation URL
      const invitationUrl = `${functions.config().app.url}/team/join/${teamId}?token=${invitationToken}`;
      
      // Email content
      const mailOptions = {
        from: `SynCodex <${functions.config().email.user}>`,
        to: member.email,
        subject: `Invitation to join ${afterData.name} team on SynCodex`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background-color: #0f0f0f; padding: 20px; text-align: center;">
              <h1 style="color: white;">SynCodex Team Invitation</h1>
            </div>
            <div style="padding: 20px; background-color: #f9f9f9;">
              <p>Hello,</p>
              <p>${adminName} has invited you to join the <strong>${afterData.name}</strong> team on SynCodex.</p>
              
              ${afterData.description ? `<p><strong>Team Description:</strong> ${afterData.description}</p>` : ''}
              
              <p>To accept this invitation and join the team, please click the button below:</p>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${invitationUrl}" style="background-color: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">Accept Invitation</a>
              </div>
              
              <p>If you didn't expect this invitation, you can safely ignore this email.</p>
              
              <p>Best regards,<br>The SynCodex Team</p>
            </div>
            <div style="background-color: #f1f1f1; padding: 15px; text-align: center; font-size: 12px; color: #666;">
              <p>This is an automated email. Please do not reply to this message.</p>
            </div>
          </div>
        `
      };
      
      // Send email
      return transporter.sendMail(mailOptions);
    });
    
    return Promise.all(emailPromises.filter(Boolean));
  });

/**
 * Cloud Function to process team invitation acceptance
 * This endpoint will be called when a user clicks the invitation link
 */
exports.processTeamInvitation = functions.https.onCall(async (data, context) => {
  const { token, teamId } = data;
  
  if (!token || !teamId) {
    throw new functions.https.HttpsError('invalid-argument', 'Missing required parameters');
  }
  
  try {
    // Find the invitation by token
    const invitationsSnapshot = await admin.firestore()
      .collection('teamInvitations')
      .where('token', '==', token)
      .where('teamId', '==', teamId)
      .get();
    
    if (invitationsSnapshot.empty) {
      throw new functions.https.HttpsError('not-found', 'Invalid or expired invitation');
    }
    
    const invitation = invitationsSnapshot.docs[0].data();
    const invitationId = invitationsSnapshot.docs[0].id;
    
    // Check if invitation has expired
    if (invitation.expiresAt && invitation.expiresAt.toDate() < new Date()) {
      throw new functions.https.HttpsError('failed-precondition', 'Invitation has expired');
    }
    
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
    }
    
    const userId = context.auth.uid;
    const userEmail = context.auth.token.email;
    
    // Verify that the invitation email matches the authenticated user's email
    if (invitation.email !== userEmail) {
      throw new functions.https.HttpsError('permission-denied', 'Email mismatch');
    }
    
    // Get the team document
    const teamRef = admin.firestore().collection('teams').doc(teamId);
    const teamSnapshot = await teamRef.get();
    
    if (!teamSnapshot.exists) {
      throw new functions.https.HttpsError('not-found', 'Team not found');
    }
    
    const teamData = teamSnapshot.data();
    
    // Update the team members array
    const updatedMembers = teamData.members.map(member => {
      if (member.email === invitation.email) {
        return { ...member, status: 'accepted', userId };
      }
      return member;
    });
    
    // Add user to active members if not already there
    const isAlreadyActive = teamData.activeMembers.some(member => member.userId === userId);
    
    const batch = admin.firestore().batch();
    
    // Update team document
    batch.update(teamRef, { members: updatedMembers });
    
    // Add to active members if not already there
    if (!isAlreadyActive) {
      batch.update(teamRef, {
        activeMembers: admin.firestore.FieldValue.arrayUnion({
          userId,
          role: 'member',
          joinedAt: admin.firestore.FieldValue.serverTimestamp()
        })
      });
    }
    
    // Delete the invitation
    batch.delete(admin.firestore().collection('teamInvitations').doc(invitationId));
    
    await batch.commit();
    
    return { success: true, teamId };
  } catch (error) {
    console.error('Error processing team invitation:', error);
    throw new functions.https.HttpsError('internal', 'Failed to process invitation');
  }
});